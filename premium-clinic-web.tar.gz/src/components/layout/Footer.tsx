import Link from "next/link";
import styles from "./Footer.module.css";

export default function Footer() {
    return (
        <footer className={styles.footer}>
            <div className={`container ${styles.footerContainer}`}>
                <div className={styles.topSection}>
                    <div className={styles.brand}>
                        <h2 className={styles.logo}>대한내과</h2>
                        <p className={styles.slogan}>여러분의 건강한 삶을 위한 평생 주치의</p>
                    </div>

                    <div className={styles.links}>
                        <div className={styles.linkGroup}>
                            <h3>바로가기</h3>
                            <ul>
                                <li><Link href="/about">병원 소개</Link></li>
                                <li><Link href="/services">진료 안내</Link></li>
                                <li><Link href="/guide">이용 안내</Link></li>
                            </ul>
                        </div>
                        <div className={styles.linkGroup}>
                            <h3>진료 시간</h3>
                            <ul>
                                <li>평일: 09:00 - 18:00</li>
                                <li>토요일: 09:00 - 13:00</li>
                                <li>점심시간: 13:00 - 14:00</li>
                                <li className={styles.highlight}>일요일, 공휴일 휴진</li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div className={styles.bottomSection}>
                    <div className={styles.contactInfo}>
                        <p>서울시 강남구 테헤란로 123, 대한빌딩 3층</p>
                        <p>TEL: 02-1234-5678 | FAX: 02-1234-5679</p>
                        <p>대표자: 김대한 | 사업자등록번호: 123-45-67890</p>
                    </div>
                    <p className={styles.copyright}>&copy; {new Date().getFullYear()} Daehan Internal Medicine Clinic. All rights reserved.</p>
                </div>
            </div>
        </footer>
    );
}
