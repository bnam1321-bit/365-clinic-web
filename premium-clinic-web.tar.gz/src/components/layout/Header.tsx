"use client";

import Link from "next/link";
import styles from "./Header.module.css";
import { Menu, X } from "lucide-react";
import { useState } from "react";

export default function Header() {
    const [isMenuOpen, setIsMenuOpen] = useState(false);

    const toggleMenu = () => {
        setIsMenuOpen(!isMenuOpen);
    };

    return (
        <header className={styles.header}>
            <div className={`container ${styles.headerContainer}`}>
                <Link href="/" className={styles.logo}>
                    <span className={styles.logoIcon}>+</span>
                    대한내과
                </Link>

                {/* Desktop Navigation */}
                <nav className={styles.nav}>
                    <ul className={styles.navList}>
                        <li><Link href="/about" className={styles.navLink}>병원 소개</Link></li>
                        <li><Link href="/services" className={styles.navLink}>진료 안내</Link></li>
                        <li><Link href="/guide" className={styles.navLink}>이용 안내</Link></li>
                        <li><Link href="/notice" className={styles.navLink}>커뮤니티</Link></li>
                    </ul>
                </nav>

                {/* Mobile Menu Button */}
                <button className={styles.menuButton} onClick={toggleMenu} aria-label="메뉴 열기">
                    {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
                </button>

                {/* Call to Action */}
                <div className={styles.cta}>
                    <Link href="/guide" className={styles.ctaButton}>진료 예약</Link>
                </div>
            </div>

            {/* Mobile Navigation Overlay */}
            {isMenuOpen && (
                <div className={styles.mobileNav}>
                    <ul className={styles.mobileNavList}>
                        <li><Link href="/about" onClick={toggleMenu}>병원 소개</Link></li>
                        <li><Link href="/services" onClick={toggleMenu}>진료 안내</Link></li>
                        <li><Link href="/guide" onClick={toggleMenu}>이용 안내</Link></li>
                        <li><Link href="/notice" onClick={toggleMenu}>커뮤니티</Link></li>
                    </ul>
                </div>
            )}
        </header>
    );
}
