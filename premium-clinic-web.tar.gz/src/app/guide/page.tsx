import styles from "./page.module.css";
import { MapPin, Clock, Phone, Calendar } from "lucide-react";
import type { Metadata } from "next";

export const metadata: Metadata = {
    title: "이용 안내 | 대한내과",
    description: "진료 시간, 오시는 길, 온라인 예약 안내.",
};

export default function Guide() {
    return (
        <div className={styles.guide}>
            {/* Page Header */}
            <section className={styles.pageHeader}>
                <div className="container">
                    <h1 className={styles.pageTitle}>예약 및 오시는 길</h1>
                    <p className={styles.pageSubtitle}>쉽고 빠르게 예약하시고 편리하게 방문하세요.</p>
                </div>
            </section>

            <section className={styles.content}>
                <div className={`container ${styles.grid}`}>

                    {/* Left Column: Info */}
                    <div className={styles.infoColumn}>
                        {/* Hours */}
                        <div className={styles.section}>
                            <h2 className={styles.sectionTitle}><Clock size={24} /> 진료 시간</h2>
                            <table className={styles.hoursTable}>
                                <tbody>
                                    <tr>
                                        <th>평일</th>
                                        <td>09:00 - 18:00</td>
                                    </tr>
                                    <tr>
                                        <th>토요일</th>
                                        <td>09:00 - 13:00</td>
                                    </tr>
                                    <tr>
                                        <th>점심시간</th>
                                        <td>13:00 - 14:00</td>
                                    </tr>
                                    <tr>
                                        <th>휴진</th>
                                        <td className={styles.closed}>일요일, 공휴일</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                        {/* Location */}
                        <div className={styles.section}>
                            <h2 className={styles.sectionTitle}><MapPin size={24} /> 오시는 길</h2>
                            <p className={styles.address}>서울시 강남구 테헤란로 123, 대한빌딩 3층</p>
                            <div className={styles.mapPlaceholder}>
                                <span>지도 보기 (카카오맵/네이버맵)</span>
                            </div>
                            <div className={styles.transport}>
                                <p><strong>지하철</strong> 2호선 강남역 1번 출구 도보 3분</p>
                                <p><strong>버스</strong> 강남역 정거장 하차</p>
                            </div>
                        </div>

                        {/* Contact */}
                        <div className={styles.section}>
                            <h2 className={styles.sectionTitle}><Phone size={24} /> 문의 전화</h2>
                            <p className={styles.phone}>02-1234-5678</p>
                        </div>
                    </div>

                    {/* Right Column: Reference Form */}
                    <div className={styles.formColumn}>
                        <div className={styles.reservationCard}>
                            <h2 className={styles.cardTitle}><Calendar size={24} /> 간편 예약 신청</h2>
                            <p className={styles.cardDesc}>연락처를 남겨주시면 상담원이 빠른 시일 내에 연락드립니다.</p>

                            <form className={styles.form}>
                                <div className={styles.formGroup}>
                                    <label htmlFor="name">이름</label>
                                    <input type="text" id="name" placeholder="홍길동" className={styles.input} />
                                </div>

                                <div className={styles.formGroup}>
                                    <label htmlFor="phone">연락처</label>
                                    <input type="tel" id="phone" placeholder="010-1234-5678" className={styles.input} />
                                </div>

                                <div className={styles.formGroup}>
                                    <label htmlFor="type">진료 항목</label>
                                    <select id="type" className={styles.select}>
                                        <option>일반 진료</option>
                                        <option>건강 검진</option>
                                        <option>수액 클리닉</option>
                                        <option>예방 접종</option>
                                    </select>
                                </div>

                                <div className={styles.formGroup}>
                                    <label htmlFor="message">문의 사항</label>
                                    <textarea id="message" rows={4} placeholder="문의하실 내용을 적어주세요." className={styles.textarea}></textarea>
                                </div>

                                <button type="button" className={styles.submitButton}>예약 상담 신청</button>
                            </form>
                        </div>
                    </div>

                </div>
            </section>
        </div>
    );
}
