import Link from "next/link";
import styles from "./page.module.css";
import { ArrowRight, Activity, Calendar, ShieldCheck } from "lucide-react";

export default function Home() {
  return (
    <div className={styles.home}>
      {/* Hero Section */}
      <section className={styles.hero}>
        <div className={`container ${styles.heroContainer}`}>
          <div className={styles.heroContent}>
            <span className={styles.badge}>믿을 수 있는 평생 주치의</span>
            <h1 className={styles.heroTitle}>
              건강한 내일을 위한<br />
              <span className={styles.highlight}>특별한 약속</span>
            </h1>
            <p className={styles.heroSubtitle}>
              대학병원급 정밀 진단 장비와 풍부한 경험의 의료진이<br />
              환자분의 건강을 세심하게 살핍니다.
            </p>
            <div className={styles.heroActions}>
              <Link href="/guide" className={styles.primaryButton}>
                진료 예약하기 <ArrowRight size={20} />
              </Link>
              <Link href="/about" className={styles.secondaryButton}>
                의료진 소개
              </Link>
            </div>
          </div>
          <div className={styles.heroVisual}>
            <div className={styles.heroCircle}></div>
            {/* Abstract visual representation */}
          </div>
        </div>
      </section>

      {/* Features Grid (Quick Preview) */}
      <section className={styles.features}>
        <div className={`container ${styles.featuresContainer}`}>
          <div className={styles.featureCard}>
            <div className={styles.iconBox}><Activity size={32} /></div>
            <h3>정밀 건강검진</h3>
            <p>최첨단 장비를 통한 정확한 진단</p>
          </div>
          <div className={styles.featureCard}>
            <div className={styles.iconBox}><ShieldCheck size={32} /></div>
            <h3>만성질환 관리</h3>
            <p>고혈압, 당뇨 등 체계적인 케어</p>
          </div>
          <div className={styles.featureCard}>
            <div className={styles.iconBox}><Calendar size={32} /></div>
            <h3>편리한 예약</h3>
            <p>모바일로 간편하게 예약하세요</p>
          </div>
        </div>
      </section>
    </div>
  );
}
