import styles from "./page.module.css";
import { Stethoscope, Award, Heart } from "lucide-react";
import type { Metadata } from "next";

export const metadata: Metadata = {
    title: "병원 소개 | 대한내과",
    description: "대한내과 김대한 원장 소개 및 진료 철학.",
};

export default function About() {
    return (
        <div className={styles.about}>
            {/* Page Header */}
            <section className={styles.pageHeader}>
                <div className="container">
                    <h1 className={styles.pageTitle}>병원 소개</h1>
                    <p className={styles.pageSubtitle}>대한내과가 추구하는 가치와 의료진을 소개합니다.</p>
                </div>
            </section>

            {/* Philosophy */}
            <section className={styles.philosophy}>
                <div className={`container ${styles.philosophyContainer}`}>
                    <div className={styles.philosophyText}>
                        <span className={styles.label}>MEDICAL PHILOSOPHY</span>
                        <h2>환자의 마음까지 치유하는<br /><span className={styles.highlight}>따뜻한 주치의</span>가 되겠습니다.</h2>
                        <p>
                            안녕하세요, 대한내과 원장 김대한입니다.<br /><br />
                            저희 병원은 단순한 질병 치료를 넘어, 환자분들의 평생 건강 동반자가 되고자 합니다.
                            대학병원 교수 출신의 풍부한 임상 경험과 최신 의료 장비를 바탕으로
                            작은 증상 하나 놓치지 않는 세심한 진료를 약속드립니다.
                        </p>
                        <ul className={styles.valuesList}>
                            <li><Heart className={styles.icon} size={20} /> 환자 중심의 맞춤형 진료</li>
                            <li><Award className={styles.icon} size={20} /> 검증된 최신 의학 지식 기반</li>
                            <li><Stethoscope className={styles.icon} size={20} /> 과잉 진료 없는 정직한 병원</li>
                        </ul>
                    </div>
                    <div className={styles.philosophyImage}>
                        {/* Placeholder for Doctor Image */}
                        <div className={styles.doctorImagePlaceholder}>
                            (원장님 사진)
                        </div>
                    </div>
                </div>
            </section>

            {/* Profile */}
            <section className={styles.profile}>
                <div className="container">
                    <div className={styles.profileCard}>
                        <div className={styles.profileHeader}>
                            <h3>김대한 대표원장</h3>
                            <span className={styles.specialty}>내과 전문의 / 소화기내과 세부전문의</span>
                        </div>
                        <div className={styles.profileContent}>
                            <div className={styles.historyGroup}>
                                <h4>주요 약력</h4>
                                <ul>
                                    <li>서울대학교 의과대학 졸업</li>
                                    <li>서울대학교병원 내과 전공의 수료</li>
                                    <li>서울대학교병원 소화기내과 전임의</li>
                                    <li>전) 서울중앙병원 내과 과장</li>
                                    <li>대한내과학회 정회원</li>
                                    <li>대한소화기내시경학회 평생회원</li>
                                </ul>
                            </div>
                            <div className={styles.historyGroup}>
                                <h4>전문 분야</h4>
                                <ul>
                                    <li>위/대장 내시경 (용종 절제술)</li>
                                    <li>소화기 질환 (위염, 역류성 식도염)</li>
                                    <li>간 질환 (지방간, 간염)</li>
                                    <li>만성질환 (고혈압, 당뇨, 고지혈증)</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    );
}
